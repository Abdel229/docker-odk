<?php

return array(

	/*
	|--------------------------------------------------------------------------
	| SEO Language Lines
	|--------------------------------------------------------------------------
	|
	*/
	"description" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut tortor rutrum massa efficitur tincidunt vel nec lacus. Curabitur porta aliquet diam, eu gravida neque lacinia.",
	"keywords" => "donations,support,creators,OnlyFans,subscription,content,odeka,social,media,africa,dons,soutien,créateurs,OnlyFans,abonnement,contenu,odeka,réseaux,sociaux,Afrique",
);
